//
//  ViewController.m
//  BankNumber
//
//  Created by mac on 2017/3/31.
//  Copyright © 2017年 865288882@qq.com. All rights reserved.
//

#define mScreenWidth [UIScreen mainScreen].bounds.size.width

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *text;

@property (nonatomic, strong) NSMutableArray *buttonA;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyBoardDissMiss)];
    [self.view addGestureRecognizer:tap];
    
    [self createView];
    [_text becomeFirstResponder];
    // Do any additional setup after loading the view, typically from a nib.
}


-(void)keyBoardDissMiss
{
    [_text resignFirstResponder];
}

-(void)createView
{
    CGFloat buttonWH = 50.0 / 2.0;
    CGFloat leftSpace = 44.0 / 2.0;
    CGFloat space = (mScreenWidth - (buttonWH * 11) -( leftSpace * 2))/10.0;
    
    _buttonA = [[NSMutableArray alloc] init];
    for (int i = 0 ; i < 11; i ++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(leftSpace +( space + buttonWH) * i, 100, buttonWH, buttonWH)];
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        button.layer.borderWidth = 10;
        button.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor blackColor]);
        button.layer.masksToBounds = YES;
        [button.titleLabel setTextAlignment:NSTextAlignmentCenter];
        [button.titleLabel setFont:[UIFont boldSystemFontOfSize:20]];
        [self.view addSubview:button];
        [_buttonA addObject:button];
    }
    
    _text = [[UITextField alloc] init];
    _text.delegate = self;
    _text.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:_text];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    if (textField.text.length >= 11) {
        if (string.length>0) {
            return NO;
        }else{
            UIButton *lastButton = [_buttonA lastObject];
            [lastButton setTitle:@"" forState:UIControlStateNormal];
            return YES;
        }
    }else{
        if (textField.text.length > 0) {
            if (string.length > 0) {
                UIButton *button = [_buttonA objectAtIndex:textField.text.length];
                [button setTitle:string forState:UIControlStateNormal];
                button.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor redColor]);
            }else{
                UIButton *button = [_buttonA objectAtIndex:textField.text.length - 1];
                [button setTitle:@"" forState:UIControlStateNormal];
                button.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor grayColor]);
            }
        }else{
            if (string.length > 0) {
                UIButton *button = [_buttonA objectAtIndex:textField.text.length];
                [button setTitle:string forState:UIControlStateNormal];
                button.layer.borderColor = (__bridge CGColorRef _Nullable)([UIColor redColor]);
            }else{
                return YES;
            }
        }
        return YES;
    }
}

-(void)buttonAction:(UIButton *)sender
{
    [_text becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
